import 'package:flutter/material.dart';
import '../personal_info_screen.dart';
import '../parents_info_screen.dart';
import '../emergency_info_screen.dart';
import '../reference_info_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  List<Widget> _widgetOptions = [
    PersonalInfoScreen(),
    ParentsInfoScreen(),
    EmergencyInfoScreen(),
    ReferenceInfoScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Student's Detail"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 4,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.4,
                  height: MediaQuery.of(context).size.width * 0.4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.blue,
                  ),
                  child: Icon(
                    Icons.person,
                    size: MediaQuery.of(context).size.width * 0.2,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Username',
                  style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
          SizedBox(height: 16),
          // MainAxisAlignment.spaceEvenly,
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SizedBox(
                    width: 7,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _selectedIndex = 0;
                      });
                    },
                    child: Text('Personal\nInfo'),
                  ),
                  SizedBox(
                    width: 7,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _selectedIndex = 1;
                      });
                    },
                    child: Text("Parents\nInfo"),
                  ),
                  SizedBox(width: 7),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _selectedIndex = 2;
                      });
                    },
                    child: Text('Emergency\nInfo'),
                  ),
                  SizedBox(width: 7),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _selectedIndex = 3;
                      });
                    },
                    child: Text('Reference\nInfo'),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 16),
          Expanded(
            flex: 10,
            child: SingleChildScrollView(
              child: _widgetOptions.elementAt(_selectedIndex),
            ),
          ),
        ],
      ),
    );
  }
}
