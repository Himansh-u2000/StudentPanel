import 'package:flutter/material.dart';

class ParentsInfoScreen extends StatelessWidget {
  final TextEditingController fatherNameController =
      TextEditingController(text: 'John Doe');
  final TextEditingController fatherOccupationController =
      TextEditingController(text: 'Engineer');
  final TextEditingController motherNameController =
      TextEditingController(text: 'Jane Doe');
  final TextEditingController motherOccupationController =
      TextEditingController(text: 'Doctor');
  final TextEditingController addressController =
      TextEditingController(text: '123 Main St');
  final TextEditingController emailController =
      TextEditingController(text: 'example@example.com');
  final TextEditingController mobileController =
      TextEditingController(text: '1234567890');

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Parent\'s Informatio',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16),
          buildInfoField('Father\'s Name', fatherNameController),
          buildInfoField('Father\'s Occupation', fatherOccupationController),
          buildInfoField('Mother\'s Name', motherNameController),
          buildInfoField('Mother\'s Occupation', motherOccupationController),
          buildInfoField('Address', addressController),
          buildInfoField('Email', emailController),
          buildInfoField('Mobile Number', mobileController),
          SizedBox(height: 16.0),
          Center(
            child: ElevatedButton(
              onPressed: () {},
              child: Text('Submit'),
            ),
          )
        ],
      ),
    );
  }

  Widget buildInfoField(String label, TextEditingController controller) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          TextField(
            controller: controller,
            // enabled: false,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.grey[200],
            ),
          ),
        ],
      ),
    );
  }
}
